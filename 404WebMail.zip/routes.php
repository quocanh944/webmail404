<?php

$router->get('/', 'controllers/index.php')->only('auth');
$router->get('/starred', 'controllers/starred.php')->only('auth');
$router->get('/spam', 'controllers/index.php')->only('auth');
$router->get('/trash', 'controllers/index.php')->only('auth');

$router->get('/register', 'controllers/registration/create.php')->only('guest');
$router->post('/register', 'controllers/registration/store.php')->only('guest');

$router->get('/login', 'controllers/session/create.php')->only('guest');
$router->post('/session', 'controllers/session/store.php')->only('guest');
$router->delete('/session', 'controllers/session/destroy.php')->only('auth');
