<!--  view để xóa một người dùng. -->
