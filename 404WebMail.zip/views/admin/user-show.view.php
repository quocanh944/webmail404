<!-- view để hiển thị thông tin chi tiết của một người dùng. -->
