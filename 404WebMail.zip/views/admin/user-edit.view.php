<!-- view để hiển thị trang cập nhật thông tin người dùng. -->
