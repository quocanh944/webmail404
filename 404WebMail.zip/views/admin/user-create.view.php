<!-- view để hiển thị trang tạo mới người dùng. -->
