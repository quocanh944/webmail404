<?php
    require(base_path("views/partials/head.php"));
    require(base_path("views/partials/nav.php"));
?>
    <h1>
        Here is admin 
    </h1>
<?php
    require(base_path("views/partials/footer.php"));
?>