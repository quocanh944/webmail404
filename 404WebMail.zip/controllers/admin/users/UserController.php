<!-- controller để xử lý các yêu cầu liên quan đến người dùng, bao gồm tạo mới, hiển thị, cập nhật, xóa và danh sách người dùng. -->
