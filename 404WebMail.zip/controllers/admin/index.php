<?php
    // dd($_SESSION);

    view("admin/index.view.php");
?>

<!-- <h1>This is admin</h1> -->

