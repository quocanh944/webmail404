<?php

view("contact.view.php", [
    'heading' => 'Contact Us',
]);