<?php

return [
    'database' => [
        'host' => 'localhost',
        'port' => 3306,
        'dbname' => '404webmail_new_demo',
        'charset' => 'utf8mb4'
    ],
];
